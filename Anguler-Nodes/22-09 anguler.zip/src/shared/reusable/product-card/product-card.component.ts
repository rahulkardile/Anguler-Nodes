import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [],
  templateUrl: './product-card.component.html',
  styleUrl: './product-card.component.css'
})
export class ProductCardComponent {
  @Input() Product = {
    id: 0,
    name: '',
    description : "",
    img: '',
    price: 0
  }

  @Output() deleteProduct = new EventEmitter();

}
