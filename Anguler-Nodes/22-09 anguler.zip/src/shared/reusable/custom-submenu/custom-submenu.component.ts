import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-submenu',
  standalone: true,
  imports: [],
  templateUrl: './custom-submenu.component.html',
  styleUrl: './custom-submenu.component.css'
})
export class CustomSubmenuComponent {

}
