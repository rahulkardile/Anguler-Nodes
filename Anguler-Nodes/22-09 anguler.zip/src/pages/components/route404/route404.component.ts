import { Component } from '@angular/core';

@Component({
  selector: 'app-route404',
  standalone: true,
  imports: [],
  templateUrl: './route404.component.html',
  styleUrl: './route404.component.css'
})
export class Route404Component {

}
