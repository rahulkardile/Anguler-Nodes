export interface IOurTeam {
    name: string,
    position: string,
    image: string,
    description: string
}